# Model Deployment and MLOps Essentials

## Published scope

Official module link: https://www.comp.nus.edu.sg/executive-education/course/sctp-model-deployment-and-mlops-essentials/

Published classroom days: 1. The week below is an original expanded self-study schedule, not the official timetable.

## Learning outcomes
- Validate an inference contract and version an artifact
- Measure drift and latency without equating drift to error
- Use rollout and rollback gates with documented assumptions

## Five-day learning plan
- Day 1: inference schema and reproducible artifacts (2h)
- Day 2: serve and validate locally (2h)
- Day 3: latency and monitoring (2h)
- Day 4: drift and rollout simulation (2h)
- Day 5: incident drill and runbook (4h)

## Project
A local standard-library prediction API and monitoring card

## Boundaries
No strong exact-course production MLOps submission was found. Hosted pages run notebooks in the browser; they are not model-serving production deployments. No cloud resources are purchased.

## Completion evidence
- Clean notebook execution and changed-control screenshots
- Exercise code and deterministic tests
- Lab log with at least two failures
- Dataset/model card where appropriate
- Assessment answers before reading the solutions
