# Source boundaries

Checked 2026-11-19. This course is an independent reconstruction.

## Official anchor
https://www.comp.nus.edu.sg/executive-education/course/sctp-model-deployment-and-mlops-essentials/

## Related work inspected
- https://github.com/anastasiapatricks/JobAId
- https://github.com/NUS-AIS-Practice-Modules/WhatsEat-backend-LangGraph-supervisor-py
- https://github.com/ISS-IS02PT/PRS-PM-ISY5002-GROUP5

Student code is evidence of project practice, not proof that a particular topic or tool is compulsory in SCTP. A filename or copied submission footer alone is weak attribution. No unlicensed student code is copied into the original learning kernels. Week 5 preserves its upstream fork under MIT, including the upstream copyright notice.
