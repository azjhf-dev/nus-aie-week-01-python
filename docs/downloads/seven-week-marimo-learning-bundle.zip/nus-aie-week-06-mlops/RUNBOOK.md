# Local deployment and rollback drill

This is a local teaching service, not production infrastructure. It binds to 127.0.0.1 and makes no cloud purchases.

1. Create the learning environment and run `python service.py`.
2. Check GET /health, then POST /predict with a JSON object containing numeric hours and practice.
3. Record the version and request result. Send a missing-field, unknown-field and non-finite input. Expect HTTP 400.
4. Run `python -m unittest discover -s learning_tests -v` to exercise a real ephemeral local server and collect request timing. A local p95 does not predict internet p95.
5. For a version exercise, make a new branch, change the formula and version together, rerun tests and compare fixed test cases.
6. Roll back by checking out the prior known-good commit and restarting. Verify /health and the same fixed test cases again.
7. Log the commit, trigger, action, measured recovery time and residual risk. Do not call an unmeasured simulation a successful production rollback.

A production extension needs authentication, TLS, timeouts, rate/body limits, dependency pinning, image scanning, metrics, label feedback and an owner. Do not expose this teaching server directly to the internet.
