"""Local-only standard-library JSON inference service. No public deployment."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import math
from labcore import serving

class Handler(BaseHTTPRequestHandler):
    def send_json(self,status,data):
        body=json.dumps(data).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_GET(self):
        if self.path=='/health': return self.send_json(200,{'status':'ok','model_version':'teaching-v1'})
        self.send_json(404,{'error':'not found'})
    def do_POST(self):
        if self.path!='/predict': return self.send_json(404,{'error':'not found'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<=0 or size>4096: raise ValueError('Body size must be 1..4096 bytes')
            payload=json.loads(self.rfile.read(size),parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Non-finite JSON number')))
            result=serving(payload)
        except (ValueError,TypeError,UnicodeDecodeError) as error:
            return self.send_json(400,{'error':str(error)})
        self.send_json(200,result)
    def log_message(self,*args):
        pass # Avoid logging payloads in this teaching service.


def serve(port=8765):
    return ThreadingHTTPServer(('127.0.0.1',port),Handler)


if __name__=='__main__':
    print('Local teaching API on http://127.0.0.1:8765; Ctrl-C stops it.')
    serve().serve_forever()
