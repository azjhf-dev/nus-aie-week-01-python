# Original self-study assessment

Not an official NUS rubric.

## Does drift prove the model needs retraining?

No. It is a signal to investigate input lineage, measurement changes and delayed-label error.

## What is required for a meaningful rollback?

A known-good version, a supported restore route, a trigger, responsible owner and verification that serving recovered.

## Build task

Run service.py locally, send valid and invalid JSON, record real request timings, change the model version, and rehearse restoring the prior artifact.

## Suggested scoring, 100 points
- Reproducible clean run and tests: 25
- Correct mechanism and explanation: 25
- Evaluation with a held-out set or explicit mechanism checks: 20
- Failure cases, provenance and limits: 20
- Readable demo and documentation: 10

Pass suggestion: 70, with no fabricated results, private-data exposure or unsupported production claims. This is a self-study convention.
