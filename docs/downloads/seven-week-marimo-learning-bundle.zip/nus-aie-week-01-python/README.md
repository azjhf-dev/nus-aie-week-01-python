# Week 1: Python and data foundations

**One module, one week, one repository.** Independent learning material mapped to the published NUS School of Computing SCTP AI Engineering objectives. Not issued, endorsed or accredited by NUS.

## Open without sign-in

https://azjhf-dev.github.io/nus-aie-week-01-python/

Choose the interactive core or one of the read-only mobile snapshots.

## What is ready

- `course.py`: reactive Marimo mechanism lab, responsive SVG charts and controllable motion graphics.
- `build_lab.py`: deeper executable project, not just a reading outline.
- `docs/notebook.html`: browser-runtime version of the core. It downloads Python/packages and needs internet.
- `docs/read.html`: executed read-only core snapshot for phones and browsers that cannot load the runtime.
- `docs/build.html`: executed read-only deeper-project snapshot. Run locally to change its inputs.
- `CURRICULUM.md`, `ASSESSMENT.md`, `LAB_LOG.md`, `SOURCES.md` and `learning_tests/`.
- `TEST_RESULTS.txt`: recorded local tests. This is evidence about this teaching build, not the entire inherited upstream application.

## Run locally

Use Python 3.11 or later. Create a dedicated environment, then install the learning dependencies, not any inherited upstream application's default environment:

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-build.txt
marimo edit course.py
# For the deeper project, open build_lab.py instead.
python -m unittest discover -s learning_tests -v
```

For CPU PyTorch weeks (3 and 4), install a CPU-compatible PyTorch wheel for your operating system. No GPU or model downloads are needed for the supplied synthetic tasks. Browser code is read-only in run mode; use local Marimo edit mode to change Python.

## Week plan

Estimated **12 active hours**, an original self-study estimate. The official module lists 2 classroom day(s); these are different quantities.

- Day 1: expressions, types, collections and functions (2h)
- Day 2: file I/O, CSV and validation (2h)
- Day 3: NumPy arrays and vector operations (2h)
- Day 4: pandas cleaning and group summaries (2h)
- Day 5: build, test and explain the audit (4h)

Submit: **A reproducible synthetic learning-activity data audit**. See ASSESSMENT.md for the original self-study rubric and answer hints.

## Important boundary

No exact SCTP Python assignments are public in the inspected evidence. The synthetic dataset and all lessons are original.

Default lessons make no external API calls, buy no compute and use no private data. Synthetic educational examples must not be used to rank real learners. Upstream live integrations can need paid provider accounts; they are not run automatically.

## Provenance

Published objective anchor: https://www.comp.nus.edu.sg/executive-education/course/sctp-python-programming-for-ai-engineering/

All newly written lessons and kernels are original. Public student work is linked as evidence, not copied without permission. No NUS logos, private teaching materials, student IDs, emails, credentials or datasets are included in the original curriculum additions.

## Seven-week sequence

- Week 1: [Python Programming for AI Engineering](https://github.com/azjhf-dev/nus-aie-week-01-python)
- Week 2: [Applied Machine Learning](https://github.com/azjhf-dev/nus-aie-week-02-machine-learning)
- Week 3: [Deep Learning and Neural Networks](https://github.com/azjhf-dev/nus-aie-week-03-deep-learning)
- Week 4: [Generative AI and its Applications](https://github.com/azjhf-dev/nus-aie-week-04-generative-ai)
- Week 5: [Large Language Models and Agentic AI](https://github.com/azjhf-dev/nus-aie-week-05-llm-agents)
- Week 6: [Model Deployment and MLOps Essentials](https://github.com/azjhf-dev/nus-aie-week-06-mlops)
- Week 7: [Capstone Project for AI Engineering](https://github.com/azjhf-dev/nus-aie-week-07-capstone)

Checked 19 November 2026.
