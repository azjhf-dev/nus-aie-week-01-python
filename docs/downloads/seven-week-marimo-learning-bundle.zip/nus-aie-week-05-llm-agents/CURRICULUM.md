# Large Language Models and Agentic AI

## Published scope

Official module link: https://www.comp.nus.edu.sg/executive-education/course/sctp-large-language-models-and-agentic-ai/

Published classroom days: 2. The week below is an original expanded self-study schedule, not the official timetable.

## Learning outcomes
- Inspect retrieval separately from answer generation
- Test a bounded state machine and review gates
- Evaluate answerability, source support and untrusted retrieved text

## Five-day learning plan
- Day 1: tokens, prompts and context budgets (3h)
- Day 2: TF-IDF retrieval, chunking and evaluation (3h)
- Day 3: grounded extractive answers and abstention (3h)
- Day 4: state machines, tool budgets and human review (3h)
- Day 5: inspect the real JobAId fork and write a test report (4h)

## Project
A synthetic study-resource assistant with retrieval evaluation

## Boundaries
The no-key core uses extractive answers and a deterministic FSM, not an LLM. The inherited JobAId application is real LangGraph/FastAPI code but its external-service integration has not been executed or security-certified here.

## Completion evidence
- Clean notebook execution and changed-control screenshots
- Exercise code and deterministic tests
- Lab log with at least two failures
- Dataset/model card where appropriate
- Assessment answers before reading the solutions
