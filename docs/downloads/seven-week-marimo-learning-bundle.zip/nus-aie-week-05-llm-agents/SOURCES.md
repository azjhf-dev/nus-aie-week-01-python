# Source boundaries

Checked 2026-11-19. This course is an independent reconstruction.

## Official anchor
https://www.comp.nus.edu.sg/executive-education/course/sctp-large-language-models-and-agentic-ai/

## Related work inspected
- https://github.com/anastasiapatricks/JobAId
- https://github.com/NUS-AIS-Practice-Modules/WhatsEat-backend-LangGraph-supervisor-py
- https://github.com/NUS-AIS-Practice-Modules/CryptoPulse
- https://github.com/bleongcw/generativeai_course

Student code is evidence of project practice, not proof that a particular topic or tool is compulsory in SCTP. A filename or copied submission footer alone is weak attribution. No unlicensed student code is copied into the original learning kernels. Week 5 preserves its upstream fork under MIT, including the upstream copyright notice.
