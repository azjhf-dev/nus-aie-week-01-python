"""Actual LangGraph, with deterministic retrieval and a resumable review interrupt.
No LLM inference or external tool action is implied by this graph.
"""
from typing import TypedDict
from langgraph.graph import StateGraph,START,END
from langgraph.types import interrupt,Command
from langgraph.checkpoint.memory import InMemorySaver
from labcore import answer

class State(TypedDict,total=False):
    query:str
    answer:str
    approved:bool
    status:str


def make_graph():
    def retrieve_node(state):
        text,_=answer(state['query'],2,.1)
        return {'answer':text,'status':'drafted'}
    def review_node(state):
        # interrupt persists the paused state; resume with a trusted UI in a real system.
        approved=interrupt({'question':'Release this demo answer?','draft':state['answer']})
        return {'approved':bool(approved),'status':'approved' if approved else 'rejected'}
    def finish_node(state):
        return {'status':'released' if state['approved'] else 'withheld'}
    graph=StateGraph(State)
    graph.add_node('retrieve',retrieve_node);graph.add_node('review',review_node);graph.add_node('finish',finish_node)
    graph.add_edge(START,'retrieve');graph.add_edge('retrieve','review');graph.add_edge('review','finish');graph.add_edge('finish',END)
    return graph.compile(checkpointer=InMemorySaver())


def run_review(approved=False):
    graph=make_graph();config={'configurable':{'thread_id':'synthetic-demo'}}
    paused=graph.invoke({'query':'How should I monitor drift?'},config=config,recursion_limit=12)
    assert '__interrupt__' in paused
    result=graph.invoke(Command(resume=approved),config=config,recursion_limit=12)
    return {'paused_for_review':True,'approved':approved,'status':result['status'],'answer':result['answer'] if approved else '(withheld)'}


if __name__=='__main__':
    import json
    print(json.dumps([run_review(False),run_review(True)],indent=2))
