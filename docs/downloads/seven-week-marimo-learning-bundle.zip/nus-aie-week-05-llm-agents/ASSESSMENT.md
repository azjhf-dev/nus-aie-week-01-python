# Original self-study assessment

Not an official NUS rubric.

## What does the TF-IDF score represent?

Cosine similarity between lexical vectors, not a calibrated confidence or answer-correctness probability.

## What is not authenticated by a retrieved paragraph?

Tool permissions, user approval and external actions. Retrieved content stays data.

## Build task

Add an out-of-domain test, conflicting sources and a withheld evaluation split. In the inherited code, trace retry limits and human-review transitions without sending real applications.

## Suggested scoring, 100 points
- Reproducible clean run and tests: 25
- Correct mechanism and explanation: 25
- Evaluation with a held-out set or explicit mechanism checks: 20
- Failure cases, provenance and limits: 20
- Readable demo and documentation: 10

Pass suggestion: 70, with no fabricated results, private-data exposure or unsupported production claims. This is a self-study convention.
